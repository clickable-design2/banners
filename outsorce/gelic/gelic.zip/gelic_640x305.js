(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.buble = function() {
	this.initialize(img.buble);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,209,119);


(lib.dver = function() {
	this.initialize(img.dver);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,169,248);


(lib.fon = function() {
	this.initialize(img.fon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,798,421);


(lib.gelickkk = function() {
	this.initialize(img.gelickkk);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,372,299);


(lib.gilick = function() {
	this.initialize(img.gilick);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,103,13);


(lib.girl = function() {
	this.initialize(img.girl);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,207,467);


(lib.kesh_presuy = function() {
	this.initialize(img.kesh_presuy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,96,15);


(lib.lopata = function() {
	this.initialize(img.lopata);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,154,159);


(lib.money = function() {
	this.initialize(img.money);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,297,112);


(lib.ne_komplex = function() {
	this.initialize(img.ne_komplex);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,112,15);


(lib.rou = function() {
	this.initialize(img.rou);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,166,166);


(lib.tree = function() {
	this.initialize(img.tree);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,258,360);


(lib.zad = function() {
	this.initialize(img.zad);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,422,324);


(lib.Слой31 = function() {
	this.initialize(img.Слой31);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,274,267);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Символ44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AL2B0IgRgGQgIgEgHgFIABgDIAEACIARAGQAKADAMAAQAeAAAWgUQALgKAKgPQAKgPAKgUIBAiGIAPAAIhFCQQgKAUgKAPQgKAPgLAKQgWAUgeAAQgMAAgKgDgAPCB2IAAgKIA6AAIAAg2IAKAAIAABAgAJeB2IAAgKIBJAAIAAjVIAKAAIAADfgAHXB2IAAgKIBKAAIAAhNIAzAAIAAAKIgpAAIAABNgAFeB2IAAgKIBJAAIAAjVIAKAAIAADfgADRB2IAAgKIBQAAIAzhsIAAAfIgpBXgAiRB2IAAgKIEyAAIAAjVIAKAAIAADfgAkDB2IgCgKIBUAAIg+jVIAHAAIADAKIA+DVgAmXB2IADgKIBQAAIAHggIApAAIACAKIghAAIgHAggAoAB2IAAgKIBJAAIAAjVIAKAAIAADfgAppB2IgDgKIA8AAIAmh8IAAAqIgcBcgArjB2IAAgKIBJAAIAAh8IAKAgIAABmgAvwB2QgPAAgOgCIAAgIIATAAIBDAAQAVAAAegFQAVgFANgIQANgJAGgLQAFgMAAgNQAAgJgCgHQgCgHgEgGIgCgDQAGAFAGAIQAEAGACAHQACAHAAAJQAAANgFAMQgGALgNAJQgNAIgVAFQgeAFgVAAgAvDA0IAAggIAMAAQAKAAAFAEQADADABAEQgEgBgFAAIgMAAIAAAWgAAsAmIAAiPIAKAAIAACPgAhHAmIAAiPIAKAAIAACPgAPGAjIgBgKIA0AAIAKiPIALAAIgLCZgAk0AZIALg5IAGAfIgFAagAp0hpIAHAAIAfBkIgEALgAt9gJIAAgCQAMgDAJgFQAIgFAGgJQAHgJAAgNQAAgMgGgLIgEgGQAJAHAFAJQAGALAAAMQAAANgHAJQgGAJgIAFIgMAGQgJgFgKgBgAEbhpIAKAAIAABOIgKAVgAvDghIAAgaIALAAQAIAAAFAEQAEADABAEIgIgBIgLAAIAAAQgAIhgmIAAhDIAKAAIAABDgAMghpIAHAAIAPAxIgEANg");
	this.shape.setTransform(104.8,12.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AL2B0IgRgGIgEgCIgLgHIATg9IAQAGIAKABIAGgCIAEgDIACgFIhIiOIBgAAIADAKIASA+IAEgNIAOg7IBgAAIgFAKIhACGQgKAUgKAPQgKAPgLAKQgWAUgeAAQgMAAgKgDgAPMB2IgKAAIAAhAIBEAAIAAAKIAAA2gAJoB2IgKAAIAAhDIAAgKIgzAAIAABNIhKAAIgKAAIAAjfIBUAAIAAAKIAABDIAKAAIApAAIAAhNIBTAAIAAAKIAADVgAFoB2IgKAAIAAhNIAAgfIgzBsIhQAAIgKAAIAAjfIBUAAIAAAKIAABiIAKgUIAphYIBZAAIAAAKIAADVgAiHB2IgKAAIAAjfIBUAAIAAAKIAACPIAKAAIAXAAIAAiZIBSAAIAAAKIAACPIAKAAIAYAAIAAiZIBTAAIAAAKIAADVgAj7B2IgIAAIgFgWIgCgKIgpAAIgHAgIhQAAIgNAAIBCjfIBtAAIADAKIA+DVgAkqAjIAMAAIALAAIgGgbIgGgegAn2B2IgKAAIAAhSIAAgqIgmB8Ig8AAIgHAAIgdhcIgKggIAAB8IhJAAIgKAAIAAjfIB2AAIADAKIAiBvIAEgMIAhhtIB2AAIAAAKIAADVgAvwB2IgTAAIgKgCIAAjdIBfAAQASAAAcAFQATAFAMAIQAJAGAFAHIAEAGQAGALAAAMQAAANgHAJQgGAJgIAFQgJAFgMADIAAABQAKABAJAFIAHADQAIAFAHAJIACADQAEAGACAHQACAHAAAJQAAANgFAMQgGALgNAJQgNAIgVAFQgeAFgVAAgAu5A+IAKAAIACAAQAKAAAFgEQAFgFAAgHIgBgFQgBgEgDgDQgFgEgKAAIgMAAgAu5gXIAKAAIABAAQAIAAAFgEQAFgEAAgFIAAgCQgBgEgEgDQgFgEgIAAIgLAAgAPPAjIgJAAIgMiZIBUAAIgBAKIgKCPg");
	this.shape_1.setTransform(103.8,11.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ44, new cjs.Rectangle(0,0,208.6,24.8), null);


(lib.Символ43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AoHCFIAAgKIBJAAIAAhjIALAAIAABtgAq0CFIAAgKIBJAAIAAgqIBaAAIAAAKIhQAAIAAAqgAJiBbIAAgKIBJAAIAAjVIAKAAIAADfgAHUBbIAAgKIBQAAIA0hrIAAAeIgqBXgAEVBbIAAgKIBJAAIAAiVIBXAAIAAhAIAKAAIAABKIhXAAIAACVgABPBbQgQAAgNgCIAAgIIATAAIBCAAQASAAAcgFQAUgGANgLQAGgFAEgGQAFgHADgHQAGgPAAgSQAAgRgGgPQgEgLgGgIIADADQALALAGAPQAGAPAAARQAAASgGAPQgDAHgFAHQgFAGgFAFQgNALgUAGQgcAFgSAAgAhHBbIAAgKIBIAAIAAjVIAKAAIAADfgAjOBbIAAgKIBKAAIAAhNIAzAAIAAAKIgpAAIAABNgAmeBbIAAgKICqAAIAAg2IAKAAIAABAgAB7AWIAAgpIAMAAQAJAAAGAGIADAGQgDgCgFAAIgMAAIAAAfgAlUARIAAgQIBTAAIAAg1IAKAAIAAA/IhTAAIAAAGgAnXAOIAAiSIAKAAIAACSgApXAOIAGgVIAFgcQABgQABgYIAfAAIAAAKIgVAAQgBAYgBAQIgFAbIgDAMgAIeiEIAKAAIAABOIgKAVgAlUg+IAAgQIBZAAIAAg2IAKAAIAABAIhZAAIAAAGgAiEhBIAAhDIAKAAIAABDgAB7hOIAAg2IAKAAIAAA2g");
	this.shape.setTransform(70.3,14.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("An9CFIgKAAIAAggIAAgKIhaAAIAAAqIhJAAIgKAAIAAhtIATAAQAHgKAFgTQAEgSADgeQADgVABg6IC9AAIAAAKIAACSIAKAAIAPAAIAAAKIAABjgApCgZIgFAbIgGAWIANAAIAfAAIAAhPIAAgKIgfAAQgBAYgBAQgAJsBbIgKAAIAAhNIAAgeIg0BrIhQAAIgKAAIAAjfIBUAAIAAAKIAABjIAKgVIAphYIBaAAIAAAKIAADVgAEfBbIgKAAIAAjfICqAAIAAAKIAABAIhXAAIAACVgABPBbIgTAAIgLgCIAAjdIBUAAIAAAKIAAA2IAKAAIATgBQAUAAAQAGQARAGAKAKIAHAHQAGAIAEALQAGAPAAARQAAASgGAPQgDAHgFAHQgEAGgGAFQgNALgUAGQgcAFgSAAgACFAgIAKAAIACAAQAJAAAGgGQAFgGAAgJQAAgFgCgEIgDgFQgGgGgJAAIgMAAgAg9BbIgKAAIAAhDIAAgKIgzAAIAABNIhKAAIgKAAIAAjfIBUAAIAAAKIAABDIAKAAIApAAIAAhNIBSAAIAAAKIAADVgAmUBbIgJAAIAAjfICsAAIAAAKIAAA2IhZAAIAAAQIAKAAIBJAAIAAAKIAAA1IhTAAIAAAQIAKAAIBWAAIAAAKIAAA2g");
	this.shape_1.setTransform(69.3,13.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ43, new cjs.Rectangle(0,0,139.5,27.6), null);


(lib.Символ42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("ABTCTQgTgIgPgNIgEgDQgQgPgIgVQgJgVAAgXQAAgYAJgTQAIgVAQgPQAQgPAWgIQAVgJAaAAQAPAAAYAFQARAGALAHQANAHAKAKIgBABIgmA5IgNgIIgNgFQgIgDgHAAQgJAAgHADQgHACgFAEQgGAGgCAGQgDAFAAAIQAAAHADAHQACAFAGAGIAEADQAKAGAOAAQAHAAAIgCIANgFIANgJIAHAMIAgAvQgKAKgNAIQgLAGgRAGQgYAGgPAAQgagBgVgIgAikCZQgNgCgMgEQgWgJgQgOIgBgBQgIgHgHgKQgGgJgFgKQgJgVAAgXQAAgYAJgTQAFgKAGgKQAHgIAIgIQARgPAWgIQAMgFANgCQAMgCAOAAQAbAAAYAJQALADAKAHQAKAFAIAIIAIAIQALAMAHAQQAJATAAAYQAAAXgJAVQgJAVgRAPQgIAIgKAFQgKAGgLAFQgYAIgbABQgOAAgMgDgAiYAMQgGACgFAFQgEAEgEAHQgCAFAAAIQAAAHACAHQAEAGAEAFIAFADIAGAEQAHACAHAAQAHAAAGgCQAHgDAFgEQAEgFAEgGQADgHAAgHQAAgIgDgFIgEgFIgEgGQgFgFgHgCQgGgDgHAAQgHAAgHADgAKCCbIgKAAIAAhNIAAggIgzBtIhQAAIgKAAIAAjfIBTAAIAAAKIAABiIAKgVIAphXIBaAAIAAAKIAADVgAGACbIgIAAIgEgWIgDgKIgpAAIgHAgIhQAAIgMAAIBBjfIBtAAIADAKIA+DVgAFSBIIALAAIALAAIgFgbIgHgfgAnZCbIgKAAIAAjfIBfAAQASAAAcAFQAUAHANAKQAFAEAEAFIABABQAFAGADAIQAGAOAAAQQAAAQgGAPQgGAPgLAJQgKAKgRAGQgQAGgUAAIgTAAIgKgCIAABIgAmQAYIAKAAIACAAQAJAAAGgFQAFgFAAgHIgBgGQgBgCgDgDQgGgFgJAAIgMAAgArACbIgKAAIAAjfICxAAIAAAKIAAAzIhdAAIAAASIAKAAIAZgBQAUAAAQAGQAQAFALAKIAIAIQAGAHADAIQAHANAAAPQAAAQgHAOQgFANgOAJQgMAKgUAGQgcAFgRAAgAp2BjIAKAAIAJAAQAJAAAFgFQAGgFAAgGIgBgEQgCgEgDgDQgFgFgJAAIgTAAgAJAhfQgIgDgGgFIgGgFQgIgJgEgLQgGgMAAgPIAxAAQgBAGADAEIACACQADADADABIAGABQAHAAAFgFQADgEAAgIIAwAAIAAAKQgBAJgDAIQgEALgJAJQgJAIgLAFQgMAEgOAAQgPAAgMgEg");
	this.shape.setTransform(71.5,15.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABTCTQgWgJgPgPIgHgHQAPANATAIQAVAIAaABQAPAAAYgGQARgGALgGQANgIAKgKIgggvIADgCIAnA7QgKAKgNAIQgLAGgRAGQgYAGgPAAQgZgBgWgIgAikCZQgNgCgMgEQgWgJgRgPIgJgJQAQAOAWAJQAMAEANACQAMADAOAAQAbgBAYgIQALgFAKgGQAKgFAIgIQARgPAJgVQAJgVAAgXQAAgYgJgTQgHgQgLgMIACACQARAPAJAVQAJATAAAYQAAAXgJAVQgJAUgRAQQgIAHgKAHQgKAFgLAFQgXAIgcABQgNAAgNgDgAJ4CbIAAgKIBJAAIAAjVIAKAAIAADfgAHrCbIAAgKIBQAAIAzhtIAAAgIgpBXgAF4CbIgCgKIBUAAIg+jVIAHAAIADAKIA/DVgADlCbIACgKIBQAAIAHggIApAAIADAKIgiAAIgHAggAnjCbIAAgKIBJAAIAAhIIAKACIATAAQAUAAAQgGQARgGAKgKQALgJAGgPQAGgPAAgPQAAgRgGgOQgDgIgFgGQAMAKAGAOQAGAOAAAQQAAAQgGAPQgFAPgMAJQgLAKgQAGQgQAFgUABIgUAAIgJgCIAABIgArKCbIAAgKIBdAAQARAAAcgFQAUgGAMgKQAOgJAFgNQAHgOAAgQQAAgPgHgNQgDgIgGgHIACACQAMAKAFANQAHANAAAQQAAAPgHAOQgFANgOAJQgMAKgTAGQgdAFgRAAgAqABZIAAggIATAAQAJAAAFAFQADADACAEQgEgCgFAAIgTAAIAAAWgAFIA+IAKg6IAHAfIgGAbgAitA6QgEgFgEgGQgCgHAAgHQAAgIACgFQAEgHAEgEQAFgFAGgCQAHgCAHAAQAHAAAGACQAHACAFAFIAEAGIgFgDQgHgDgHAAQgHAAgGADQgHACgFAFQgFAEgDAHQgCAFAAAIQAAAHACAHIADAEIgFgDgABmA6QgGgGgCgFQgDgHAAgHQAAgIADgFQACgGAGgGQAFgEAHgCQAHgCAJAAQAHAAAIACIANAFIANAIIAmg5IALAJIgnA6IgNgIIgNgFQgHgDgIAAQgJAAgHADQgHACgFAEQgFAGgEAGQgCAFAAAIQAAAHACAHIADAEIgEgDgAI0hEIAKAAIAABNIgKAVgAmaAOIAAghIAMAAQAJAAAGAFQADADABADQgEgBgFAAIgMAAIAAAXgAqAgRIBdAAIAAgzIAKAAIAAA9IhdAAIAAAIIgKAAgAJBhfQgMgFgJgIIgEgFQAGAFAIADQAMAEAPAAQAOAAAMgEQALgFAJgIQAJgJAEgLQADgIABgJIALAAQAAAPgFAMQgFALgIAJQgJAIgLAFQgMAFgOgBQgPABgLgFgAJFiZIgCgCIAIAAIAAAGQgDgBgDgDg");
	this.shape_1.setTransform(72.5,16.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ42, new cjs.Rectangle(0,0,143.9,32.1), null);


(lib.Символ34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AjgA+IAAi6IHBA+IAAC7g");
	this.shape.setTransform(22.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ34, new cjs.Rectangle(0,0,45,25), null);


(lib.Символ31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.518)","rgba(0,0,0,0)"],[0,1],0,56.4,0,-56.3).s().p("Eg0gAH5IAAvxMBpBAAAIAAPxg");
	this.shape.setTransform(336.1,50.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ31, new cjs.Rectangle(0,0,672.2,101.1), null);


(lib.Символ30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AGJCLIAAgUIBJAAIAAhYIAKAAIAABsgADcCLIAAgUIBJAAIAAgpIBaAAIAAAUIhQAAIAAApgAVaBiIAAgUIA6AAIAAgsIAKAAIAABAgASSBiIAAgUIBKAAIAAiWIBWAAIAAg1IAKAAIAABJIhWAAIAACWgAPCBiIAAgUICqAAIAAgsIAKAAIAABAgANJBiIAAgUIBJAAIAAjLIAKAAIAADfgALCBiIAAgUIBKAAIAAhNIAzAAIAAAUIgpAAIAABNgAHyBiIAAgUICqAAIAAgsIAKAAIAABAgAA2BiIAAgUIBJAAIAAjLIAKAAIAADfgAhWBiIAAgUIBQAAIAyhsIAAAoIgpBYgAk8BiIAAgUIBdAAQARAAAcgGQAUgFAMgKQANgKAGgNQAGgNAAgQQAAgKgDgKIAHANQAGAMAAAPQAAAQgGANQgGANgNAKQgMAKgUAFQgcAGgRAAgAoMBiIAAgUICqAAIAAgsIAKAAIAABAgArvBiIAAgUIBKAAIAAhIIAJABIAUAAQAUAAAQgFQAQgFALgKQALgKAGgOQAGgPAAgQQAAgNgEgLQAFAFADAHQAGAPAAARQAAAQgGAPQgGAOgLAJQgLAKgQAGQgQAFgUAAIgUAAIgJgBIAABIgAuvBiIAAgUIBKAAIAAiWIBWAAIAAg1IAKAAIAABJIhWAAIAACWgAwhBiIgEgUIBWAAIg7jLIAEAAIADAKIA+DVgAy1BiIAGgUIBNAAIAHggIApAAIAEAUIgjAAIgHAggA0eBiIAAgUIBJAAIAAjLIAKAAIAADfgA2lBiIAAgUIBKAAIAAhNIAzAAIAAAUIgpAAIAABNgAjyAWIAAgfIATAAQAIAAAGAFQAFAEAAAGIgBAFQgEgBgEAAIgTAAIAAAMgAWUAPIAAgBIg2AAIgCgSIA1AAIAJiGIAMAAIgLCZgAQMAOIAAgPIBTAAIAAgsIAKAAIAAA7gAI8AOIAAgPIBTAAIAAgsIAKAAIAAA7gAnCAOIAAgPIBTAAIAAgsIAKAAIAAA7gAG5ALIAAiIIAKAAIAACIgAE5ALIAGgVIAFgcQABgRAAgXIAgAAIAAAUIgWAAQAAAXgBARIgFAbIAAACgAxSgEIALg6IAHAjIgEAXgAgMh9IAKAAIAABDIgKAWgAqlg0IAAgiIAMAAQAJAAAFAFQAGAFAAAHIgBAFQgEgCgFAAIgMAAIAAAOgARfg9IAAgEIhTAAIAAgQIBZAAIAAgsIAKAAIAABAgAKPg9IAAgEIhTAAIAAgQIBZAAIAAgsIAKAAIAABAgAlvg9IAAgEIhTAAIAAgQIBZAAIAAgsIAKAAIAABAgAi4hAQgLgCgMAAIgjABIAAgTIBcAAIAAgpIAKAAIAAA9gAMMhEIAAg5IAKAAIAAA5gA1bhEIAAg5IAKAAIAAA5g");
	this.shape.setTransform(145.6,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AGTCLIgKAAIAAgVIAAgUIhaAAIAAApIhJAAIgKAAIAAhsIATAAQAHgKAFgVQAEgQADgfQADgUABg6IC9AAIAAAUIAACIIAKAAIAPAAIAAAUIAABYgAFOgSIgFAbIgGAWIAQAAIAcAAIAAhFIAAgUIggAAQAAAXgBARgAVkBiIgKAAIAAhAIAOAAIA2AAIAAABIAAATIAAAsgAScBiIgKAAIAAjfICqAAIAAAUIAAA1IhWAAIAACWgAPMBiIgKAAIAAjfICtAAIAAAUIAAAsIhZAAIAAAQIBTAAIAAAEIAAAQIAAArIhTAAIAAAQIBdAAIADAAIAAAUIAAAsgANTBiIgKAAIAAg5IAAgUIgzAAIAABNIhKAAIgKAAIAAjfIBUAAIAAAUIAAA5IAKAAIApAAIAAhNIBTAAIAAAUIAADLgAH8BiIgKAAIAAjfICtAAIAAAUIAAAsIhZAAIAAAQIBTAAIAAAEIAAAQIAAArIhTAAIAAAQIBdAAIADAAIAAAUIAAAsgABABiIgKAAIAAhEIAAgoIgzBsIhPAAIgKAAIAAjfIBUAAIAAAUIAABZIAJgWIAphXIBZAAIAAAUIAADLgAkyBiIgKAAIAAjfICwAAIAAAUIAAApIhcAAIAAATIAjgBQAMAAALACIANADQAQAGALAKQALAJAGAOIADAGQADAKAAALQAAAQgGANQgGANgNAKQgMAKgUAFQgcAGgRAAgAjoAqIAKAAIAJAAQAIAAAGgFIAEgGIABgFQAAgGgFgFQgGgFgIAAIgTAAgAoCBiIgKAAIAAjfICtAAIAAAUIAAAsIhZAAIAAAQIBTAAIAAAEIAAAQIAAArIhTAAIAAAQIBdAAIADAAIAAAUIAAAsgArlBiIgKAAIAAjfIBgAAQASAAAcAFQATAGANAKQANAKAGAOIACAIQAEALAAANQAAAQgGAPQgGAOgLAJQgLAKgQAGQgQAFgUAAIgUAAIgJgBIAABIgAqbggIAKAAIACAAQAJAAAFgFQAEgDABgEIABgFQAAgHgGgFQgFgFgJAAIgMAAgAulBiIgKAAIAAjfICqAAIAAAUIAAA1IhWAAIAACWgAwbBiIgGAAIgDgMIgEgUIgpAAIgHAgIhNAAIgQAAIBCjfIBtAAIADAKIADAKIA7DLgAxIAPIAOAAIAJAAIgFgWIgHgjgA0UBiIgKAAIAAg5IAAgUIgzAAIAABNIhKAAIgKAAIAAjfIBUAAIAAAUIAAA5IAKAAIApAAIAAhNIBTAAIAAAUIAADLgAVmAPIgIAAIgMiZIBUAAIgCAUIgJCFg");
	this.shape_1.setTransform(144.6,13.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ30, new cjs.Rectangle(0,0,290.2,29.9), null);


(lib.Символ21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.zad();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ21, new cjs.Rectangle(0,0,422,324), null);


(lib.Символ19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.ne_komplex();
	this.instance.parent = this;
	this.instance.setTransform(17,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ19, new cjs.Rectangle(17,0,112,15), null);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.gilick();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ18, new cjs.Rectangle(0,0,103,13), null);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.kesh_presuy();
	this.instance.parent = this;
	this.instance.setTransform(-10,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ17, new cjs.Rectangle(-10,0,96,15), null);


(lib.Символ16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.money();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.643,0.643);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ16, new cjs.Rectangle(0,0,191,72.1), null);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Слой31();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.672,0.672);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15, new cjs.Rectangle(0,0,184,179.3), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.money();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.63,0.63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13, new cjs.Rectangle(0,0,187,70.5), null);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AIfFxQiTgDh0g6IgCAAQgVgDgNgFQgPgGgWgUQgogggJgZQgJgZAJgaQAJgbAWgOQAXgNAcAEQAcAEARATIACACQALACANAFIASAKQAUAAAlADQAoADAVgCIAXgCQAPgCAJABQAUACARAMQAQAMAIAPIAjgCQBjgGA1gMQBUgUA1gsIAXgVQAOgLAMgFQAXgJAZAIQAaAIAOAVQAQAbgIAkQgHAggYAcQgfAlg0AaQgoAVg7ARQiFAmh7AAIgMAAgA2BDdIg7gFQgdgChQAAQhFABgpgFQhCgJgZgiQgJgOgDgRQgDgRAFgQQAKghAhgOQAQgGAWAAQALAAAdADQBQAKBkgCQA/gBB2gIQAWgBANgFQAFgCAPgLQAMgIAJgBQAIgCAOADQARADAGAAQAVABAbgXQAjgdAKgFQARgIASABQATABAPAJQAQAKAJAPQAKAQAAASQACAqgrAoQgkAig5AXQgpARhBAPQhPATgsAAIgGABQgWAAgegEgAViB0IhAgFIgygCQgcgDgUgHQgZgIgRgRQgUgTgDgXIgCgYIgEgOIgEgOQgEgTAFgTQADgQAKgMIgUgIQgpgTheggQgtgPgYgGIgYgGQhQgEhQgCQgfgBgPgDQgagFgQgNQgYgTgCgiQgBgiAXgUQANgMAWgFQAPgEAZgCQAmgCA3ABQANgBAPABQASABATACIArADQCMAKA9gCIA6AAQAhABAXAHQAdAKAuAhQAJgVAWgPQAUgNAZgEQAhgFA/AMQAGgYAWgRQAWgQAaABQAMAAAcAIQAaAIAPgCQAJAAARgGQASgGAJgBQAZgCAWAQQAVAQAKAYQAPAjgGBBQgIBmgdA8QgTAngeAbQghAegnAKQgWAHgXgBQgJAMgOAKQgvAihLABIgHABQgYAAghgDg");
	this.shape.setTransform(179.2,33.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ11, new cjs.Rectangle(0,-3.6,358.4,73.8), null);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.girl();
	this.instance.parent = this;
	this.instance.setTransform(25,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ8, new cjs.Rectangle(25,0,207,467), null);


(lib.Символ7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.tree();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7, new cjs.Rectangle(0,0,258,360), null);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFCC00","rgba(255,204,51,0)"],[0,1],0,0,0,0,0,26.1).s().p("Ai3CgQhMhDAAhdQAAhcBMhDQBNhCBqAAQBrAABNBCQBMBDAABcQAABdhMBDQhNBChrgBQhqABhNhCg");
	this.shape.setTransform(26,22.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6, new cjs.Rectangle(0,0,52,45.1), null);


(lib.Символ4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.gelickkk();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4, new cjs.Rectangle(0,0,372,299), null);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.fon();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1, new cjs.Rectangle(0,0,798,421), null);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.rou();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.067,0.067);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ14, new cjs.Rectangle(0,0,11.1,11.1), null);


(lib.Символ13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance_1 = new lib.rou();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13_1, new cjs.Rectangle(0,0,166,166), null);


(lib.копияshape149 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF99").s().p("AjtgCICyAAIhQigIEPAAIhECgICuAAIjuClg");
	this.shape.setTransform(0,10);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.8,-6.4,47.6,32.7);


(lib.Анимация5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.buble();
	this.instance.parent = this;
	this.instance.setTransform(-104.5,-59.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104.5,-59.5,209,119);


(lib.Анимация2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.dver();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-124,0.74,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-124,125,248);


(lib.lopata_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.lopata();
	this.instance.parent = this;
	this.instance.setTransform(-77,-79.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.lopata_1, new cjs.Rectangle(-77,-79.5,154,159), null);


(lib.sprite136 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.sprite136, null, null);


(lib.shape142 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF00").ss(8.9,1,1).p("AKKqJQELELAAF+QAAF+kLEMQkLEMl/AAQl+AAkLkMQkMkMAAl+QAAl+EMkLQELkMF+AAQF/AAELEMg");
	this.shape.setTransform(199.7,1.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(103.5,-94.4,192.3,192.3);


(lib.shape137 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("AIoCbIxQibIRQiaIABAAIAAE1g");
	this.shape.setTransform(-51.2,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.5,-13.3,110.7,31.1);


(lib.shape132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF1D4").s().p("AhVhAIAVgWICXCXIgWAWg");
	this.shape.setTransform(-73.1,-72.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF1D4").s().p("AhVhAIAVgWICWCXIgVAWg");
	this.shape_1.setTransform(72.8,73);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEF1D4").s().p("AhVBBICWiWIAVAVIiWCXg");
	this.shape_2.setTransform(-72.9,73.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF1D4").s().p("AhWBBICXiXIAVAWIiWCWg");
	this.shape_3.setTransform(73.1,-73);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.7,-81.7,163.5,163.4);


(lib.Символ41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ19();
	this.instance.parent = this;
	this.instance.setTransform(39,7.5,1,1,0,0,0,56,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ41, new cjs.Rectangle(0,0,112,15), null);


(lib.Символ37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ16();
	this.instance.parent = this;
	this.instance.setTransform(156.5,93,1.639,1.639,0,0,0,95.5,36);

	this.instance_1 = new lib.Символ13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(611.5,35.2,1,1,0,0,0,93.5,35.2);

	this.instance_2 = new lib.Символ13();
	this.instance_2.parent = this;
	this.instance_2.setTransform(579.5,77.2,1,1,0,0,0,93.5,35.2);

	this.instance_3 = new lib.money();
	this.instance_3.parent = this;
	this.instance_3.setTransform(233,34);

	this.instance_4 = new lib.money();
	this.instance_4.parent = this;
	this.instance_4.setTransform(385,34);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ37, new cjs.Rectangle(0,0,705,152.1), null);


(lib.Символ33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ34();
	this.instance.parent = this;
	this.instance.setTransform(22.5,12.5,1,1,0,0,0,22.5,12.5);
	this.instance.shadow = new cjs.Shadow("rgba(255,0,0,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ33, new cjs.Rectangle(-6,-6,61,41), null);


(lib.Символ32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ6();
	this.instance.parent = this;
	this.instance.setTransform(26,29.1,1,1,0,0,0,26,22.6);
	this.instance.compositeOperation = "lighter";

	this.instance_1 = new lib.Символ6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(206.6,22.6,1,1,0,0,0,26,22.6);
	this.instance_1.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ32, new cjs.Rectangle(0,0,232.6,51.6), null);


(lib.Символ29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ30();
	this.instance.parent = this;
	this.instance.setTransform(145.1,14.9,1,1,0,0,0,145.1,14.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.04,scaleY:1.04,x:145.2,y:15},4,cjs.Ease.get(-1)).to({scaleX:1.08,scaleY:1.08,y:14.9},5,cjs.Ease.get(1)).to({scaleX:1.04,scaleY:1.04},5,cjs.Ease.get(-1)).to({scaleX:1,scaleY:1,x:145.1},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,290.2,29.9);


(lib.Символ28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1 - копия
	this.instance = new lib.Символ29();
	this.instance.parent = this;
	this.instance.setTransform(149,25.6,1,1,2,0,0,145.1,15);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-2.2,x:149.1},2).to({rotation:2,x:149},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.5,5.6,291,40);


(lib.Символ26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Символ 44
	this.instance = new lib.Символ44();
	this.instance.parent = this;
	this.instance.setTransform(404.1,19.7,1,1,0,0,0,104.2,12.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({x:394.1},2).to({x:404.1},10).wait(1));

	// Символ 43
	this.instance_1 = new lib.Символ43();
	this.instance_1.parent = this;
	this.instance_1.setTransform(221,22.5,1,1,0,0,0,69.8,13.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({x:211},2).to({x:221},10).wait(8));

	// Символ 42
	this.instance_2 = new lib.Символ42();
	this.instance_2.parent = this;
	this.instance_2.setTransform(72,16.1,1,1,0,0,0,72,16.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:62},2).to({x:72},10).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,508.5,36.2);


(lib.Символ25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ26();
	this.instance.parent = this;
	this.instance.setTransform(254.2,18.1,1,1,0,0,0,254.2,18.1);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,0,7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ25, new cjs.Rectangle(-4,-4,520,48), null);


(lib.Символ24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1 - копия
	this.instance = new lib.Символ25();
	this.instance.parent = this;
	this.instance.setTransform(257.1,20.4,1,1,0,0,0,254.2,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ24, new cjs.Rectangle(-1.1,-1.7,521,48), null);


(lib.Символ20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Анимация2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(62.5,124);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ20, new cjs.Rectangle(0,0,125,248), null);


(lib.Символ14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance_1 = new lib.Символ8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(103.5,233.5,1,1,0,0,0,103.5,233.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:238.3},9,cjs.Ease.get(-1)).to({y:243.5},10,cjs.Ease.get(1)).to({y:238.5},10,cjs.Ease.get(-1)).to({y:233.5},10,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25,0,207,467);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ32();
	this.instance.parent = this;
	this.instance.setTransform(116.2,25.8,1,1,0,0,0,116.2,25.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({alpha:1,compositeOperation:NaN},4).to({alpha:0},4).to({alpha:1,compositeOperation:NaN},4).to({alpha:0},4).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,232.6,51.6);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Символ 19
	this.instance = new lib.Символ41();
	this.instance.parent = this;
	this.instance.setTransform(164,35.5,1,1,0,0,0,56,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.21,scaleY:1.21,x:164.1,y:35.6},6).to({scaleX:1,scaleY:1,x:164,y:35.5},6).wait(1));

	// Символ 18
	this.instance_1 = new lib.Символ18();
	this.instance_1.parent = this;
	this.instance_1.setTransform(140.5,53.6,1.243,1.243,0,0,0,51.5,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:51.6,regY:6.6,scaleX:1.05,scaleY:1.05,x:140.7,y:53.7},6).to({regX:51.5,regY:6.5,scaleX:1.24,scaleY:1.24,x:140.5,y:53.6},6).wait(1));

	// Символ 17
	this.instance_2 = new lib.Символ17();
	this.instance_2.parent = this;
	this.instance_2.setTransform(179,74.5,1,1,0,0,0,48,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1.18,scaleY:1.18,x:179.1,y:74.6},6).to({scaleX:1,scaleY:1,x:179,y:74.5},6).wait(1));

	// buble
	this.instance_3 = new lib.Анимация5("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(144.5,59.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(40,0,209,119);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.instance = new lib.Символ10();
	this.instance.parent = this;
	this.instance.setTransform(149.3,141.8,1,1,0,0,0,116.2,25.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой 1
	this.instance_1 = new lib.Символ4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(208,149.5,1,1,0,0,0,186,149.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Слой 3
	this.instance_2 = new lib.Символ11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(229.7,265.1,1,1,0,0,0,169.8,35.1);
	this.instance_2.alpha = 0.75;
	this.instance_2.filters = [new cjs.BlurFilter(4, 4, 1)];
	this.instance_2.cache(-2,-6,362,78);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ5, new cjs.Rectangle(22,0,402.9,306.4), null);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ1();
	this.instance.parent = this;
	this.instance.setTransform(742.2,338.5,1,1,0,0,0,399,210.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ2, new cjs.Rectangle(343.2,128,798,421), null);


(lib.Символ15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (this.currentFrame = true){
		this.gotoAndPlay(Math.random() * 160);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(160));

	// Слой 1
	this.instance_1 = new lib.Символ14();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.5,5.5,1,1,0,0,0,5.5,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-108.5,y:1467.7},159).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.1,11.1);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (this.currentFrame = true){
		this.gotoAndPlay(Math.random() * 30);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// Слой 1
	this.instance = new lib.Символ13_1();
	this.instance.parent = this;
	this.instance.setTransform(83,83,1,1,0,0,0,83,83);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:1192.5,y:5062.7},29).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,166,166);


(lib.sprite150 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.копияshape149("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.992,1.992);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite150, new cjs.Rectangle(-47.4,-12.7,94.8,65.2), null);


(lib.sprite143 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape142("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-199.3,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite143, new cjs.Rectangle(-95.8,-94.4,192.3,192.3), null);


(lib.sprite138 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape137("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite138, new cjs.Rectangle(-106.5,-13.3,110.7,31.1), null);


(lib.sprite133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.shape132("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-3.4,0,1,1,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite133, new cjs.Rectangle(-117.4,-114,227.8,228), null);


(lib.Символ39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ37();
	this.instance.parent = this;
	this.instance.setTransform(352.5,76,1,1,0,0,0,352.5,76);
	this.instance.filters = [new cjs.ColorFilter(0.5, 0.5, 0.5, 1, 0, 127.5, 0, 0)];
	this.instance.cache(-2,-2,709,156);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ39, new cjs.Rectangle(0,0,705,152.1), null);


(lib.Символ38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1 - копия
	this.instance = new lib.Символ39();
	this.instance.parent = this;
	this.instance.setTransform(352.5,76,1,1,0,0,0,352.5,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},8).to({alpha:1},10).wait(1));

	// Слой 1
	this.instance_1 = new lib.Символ37();
	this.instance_1.parent = this;
	this.instance_1.setTransform(352.5,76,1,1,0,0,0,352.5,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,705,152.1);


(lib.Символ35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ33();
	this.instance.parent = this;
	this.instance.setTransform(22.5,12.5,1,1,0,0,0,22.5,12.5);
	this.instance.compositeOperation = "lighter";

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},5).to({alpha:1},4).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-6,61,41);


(lib.Символ18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance_1 = new lib.Символ12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(723.1,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_2 = new lib.Символ12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(676.1,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_3 = new lib.Символ12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(628,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_4 = new lib.Символ12();
	this.instance_4.parent = this;
	this.instance_4.setTransform(581,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_5 = new lib.Символ12();
	this.instance_5.parent = this;
	this.instance_5.setTransform(533,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_6 = new lib.Символ12();
	this.instance_6.parent = this;
	this.instance_6.setTransform(486,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_7 = new lib.Символ12();
	this.instance_7.parent = this;
	this.instance_7.setTransform(438,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_8 = new lib.Символ12();
	this.instance_8.parent = this;
	this.instance_8.setTransform(391,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_9 = new lib.Символ12();
	this.instance_9.parent = this;
	this.instance_9.setTransform(345,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_10 = new lib.Символ12();
	this.instance_10.parent = this;
	this.instance_10.setTransform(298,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_11 = new lib.Символ12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(250,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_12 = new lib.Символ12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(203,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_13 = new lib.Символ12();
	this.instance_13.parent = this;
	this.instance_13.setTransform(155,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_14 = new lib.Символ12();
	this.instance_14.parent = this;
	this.instance_14.setTransform(108,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_15 = new lib.Символ12();
	this.instance_15.parent = this;
	this.instance_15.setTransform(59.9,12.9,0.156,0.156,0,0,0,83,83);

	this.instance_16 = new lib.Символ12();
	this.instance_16.parent = this;
	this.instance_16.setTransform(12.9,12.9,0.156,0.156,0,0,0,83,83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ18_1, new cjs.Rectangle(0,0,736,25.8), null);


(lib.Символ17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance_1 = new lib.Символ12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(628.5,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_2 = new lib.Символ12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(608.3,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.instance_3 = new lib.Символ12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(587.8,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_4 = new lib.Символ12();
	this.instance_4.parent = this;
	this.instance_4.setTransform(567.7,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_5 = new lib.Символ12();
	this.instance_5.parent = this;
	this.instance_5.setTransform(547.2,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_6 = new lib.Символ12();
	this.instance_6.parent = this;
	this.instance_6.setTransform(527,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.instance_7 = new lib.Символ12();
	this.instance_7.parent = this;
	this.instance_7.setTransform(506.5,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_8 = new lib.Символ12();
	this.instance_8.parent = this;
	this.instance_8.setTransform(486.4,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_9 = new lib.Символ12();
	this.instance_9.parent = this;
	this.instance_9.setTransform(466.7,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_10 = new lib.Символ12();
	this.instance_10.parent = this;
	this.instance_10.setTransform(446.6,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_11 = new lib.Символ12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(426.1,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_12 = new lib.Символ12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(406,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_13 = new lib.Символ12();
	this.instance_13.parent = this;
	this.instance_13.setTransform(385.4,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_14 = new lib.Символ12();
	this.instance_14.parent = this;
	this.instance_14.setTransform(365.3,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_15 = new lib.Символ12();
	this.instance_15.parent = this;
	this.instance_15.setTransform(344.8,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_16 = new lib.Символ12();
	this.instance_16.parent = this;
	this.instance_16.setTransform(324.6,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.instance_17 = new lib.Символ12();
	this.instance_17.parent = this;
	this.instance_17.setTransform(309.4,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_18 = new lib.Символ12();
	this.instance_18.parent = this;
	this.instance_18.setTransform(289.2,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.instance_19 = new lib.Символ12();
	this.instance_19.parent = this;
	this.instance_19.setTransform(268.7,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_20 = new lib.Символ12();
	this.instance_20.parent = this;
	this.instance_20.setTransform(248.6,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_21 = new lib.Символ12();
	this.instance_21.parent = this;
	this.instance_21.setTransform(228.1,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_22 = new lib.Символ12();
	this.instance_22.parent = this;
	this.instance_22.setTransform(207.9,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.instance_23 = new lib.Символ12();
	this.instance_23.parent = this;
	this.instance_23.setTransform(187.4,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_24 = new lib.Символ12();
	this.instance_24.parent = this;
	this.instance_24.setTransform(167.3,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_25 = new lib.Символ12();
	this.instance_25.parent = this;
	this.instance_25.setTransform(147.6,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_26 = new lib.Символ12();
	this.instance_26.parent = this;
	this.instance_26.setTransform(127.5,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_27 = new lib.Символ12();
	this.instance_27.parent = this;
	this.instance_27.setTransform(107,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_28 = new lib.Символ12();
	this.instance_28.parent = this;
	this.instance_28.setTransform(86.9,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_29 = new lib.Символ12();
	this.instance_29.parent = this;
	this.instance_29.setTransform(66.3,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_30 = new lib.Символ12();
	this.instance_30.parent = this;
	this.instance_30.setTransform(46.2,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_31 = new lib.Символ12();
	this.instance_31.parent = this;
	this.instance_31.setTransform(25.7,5.6,0.067,0.067,0,0,0,83.4,83.4);

	this.instance_32 = new lib.Символ12();
	this.instance_32.parent = this;
	this.instance_32.setTransform(5.5,5.6,0.067,0.067,0,0,0,82.7,83.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ17_1, new cjs.Rectangle(0,0,634,11.1), null);


(lib.Символ16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance_1 = new lib.Символ15_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(679.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_2 = new lib.Символ15_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(672.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_3 = new lib.Символ15_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(662.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_4 = new lib.Символ15_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(655,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_5 = new lib.Символ15_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(648.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_6 = new lib.Символ15_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(640.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_7 = new lib.Символ15_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(631.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_8 = new lib.Символ15_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(623.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_9 = new lib.Символ15_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(618.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_10 = new lib.Символ15_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(610.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_11 = new lib.Символ15_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(600.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_12 = new lib.Символ15_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(593.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_13 = new lib.Символ15_1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(586.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_14 = new lib.Символ15_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(579,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_15 = new lib.Символ15_1();
	this.instance_15.parent = this;
	this.instance_15.setTransform(569.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_16 = new lib.Символ15_1();
	this.instance_16.parent = this;
	this.instance_16.setTransform(561.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_17 = new lib.Символ15_1();
	this.instance_17.parent = this;
	this.instance_17.setTransform(556.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_18 = new lib.Символ15_1();
	this.instance_18.parent = this;
	this.instance_18.setTransform(548.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_19 = new lib.Символ15_1();
	this.instance_19.parent = this;
	this.instance_19.setTransform(538.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_20 = new lib.Символ15_1();
	this.instance_20.parent = this;
	this.instance_20.setTransform(531.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_21 = new lib.Символ15_1();
	this.instance_21.parent = this;
	this.instance_21.setTransform(524.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_22 = new lib.Символ15_1();
	this.instance_22.parent = this;
	this.instance_22.setTransform(517,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_23 = new lib.Символ15_1();
	this.instance_23.parent = this;
	this.instance_23.setTransform(507.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_24 = new lib.Символ15_1();
	this.instance_24.parent = this;
	this.instance_24.setTransform(499.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_25 = new lib.Символ15_1();
	this.instance_25.parent = this;
	this.instance_25.setTransform(494.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_26 = new lib.Символ15_1();
	this.instance_26.parent = this;
	this.instance_26.setTransform(486.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_27 = new lib.Символ15_1();
	this.instance_27.parent = this;
	this.instance_27.setTransform(477,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_28 = new lib.Символ15_1();
	this.instance_28.parent = this;
	this.instance_28.setTransform(469.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_29 = new lib.Символ15_1();
	this.instance_29.parent = this;
	this.instance_29.setTransform(462.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_30 = new lib.Символ15_1();
	this.instance_30.parent = this;
	this.instance_30.setTransform(455.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_31 = new lib.Символ15_1();
	this.instance_31.parent = this;
	this.instance_31.setTransform(445.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_32 = new lib.Символ15_1();
	this.instance_32.parent = this;
	this.instance_32.setTransform(437.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_33 = new lib.Символ15_1();
	this.instance_33.parent = this;
	this.instance_33.setTransform(432.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_34 = new lib.Символ15_1();
	this.instance_34.parent = this;
	this.instance_34.setTransform(424.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_35 = new lib.Символ15_1();
	this.instance_35.parent = this;
	this.instance_35.setTransform(415,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_36 = new lib.Символ15_1();
	this.instance_36.parent = this;
	this.instance_36.setTransform(407.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_37 = new lib.Символ15_1();
	this.instance_37.parent = this;
	this.instance_37.setTransform(400.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_38 = new lib.Символ15_1();
	this.instance_38.parent = this;
	this.instance_38.setTransform(393.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_39 = new lib.Символ15_1();
	this.instance_39.parent = this;
	this.instance_39.setTransform(383.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_40 = new lib.Символ15_1();
	this.instance_40.parent = this;
	this.instance_40.setTransform(375.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_41 = new lib.Символ15_1();
	this.instance_41.parent = this;
	this.instance_41.setTransform(370.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_42 = new lib.Символ15_1();
	this.instance_42.parent = this;
	this.instance_42.setTransform(362.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_43 = new lib.Символ15_1();
	this.instance_43.parent = this;
	this.instance_43.setTransform(353.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_44 = new lib.Символ15_1();
	this.instance_44.parent = this;
	this.instance_44.setTransform(345.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_45 = new lib.Символ15_1();
	this.instance_45.parent = this;
	this.instance_45.setTransform(338.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_46 = new lib.Символ15_1();
	this.instance_46.parent = this;
	this.instance_46.setTransform(331.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_47 = new lib.Символ15_1();
	this.instance_47.parent = this;
	this.instance_47.setTransform(321.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_48 = new lib.Символ15_1();
	this.instance_48.parent = this;
	this.instance_48.setTransform(314.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_49 = new lib.Символ15_1();
	this.instance_49.parent = this;
	this.instance_49.setTransform(308.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_50 = new lib.Символ15_1();
	this.instance_50.parent = this;
	this.instance_50.setTransform(300.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_51 = new lib.Символ15_1();
	this.instance_51.parent = this;
	this.instance_51.setTransform(291.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_52 = new lib.Символ15_1();
	this.instance_52.parent = this;
	this.instance_52.setTransform(283.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_53 = new lib.Символ15_1();
	this.instance_53.parent = this;
	this.instance_53.setTransform(276.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_54 = new lib.Символ15_1();
	this.instance_54.parent = this;
	this.instance_54.setTransform(269.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_55 = new lib.Символ15_1();
	this.instance_55.parent = this;
	this.instance_55.setTransform(259.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_56 = new lib.Символ15_1();
	this.instance_56.parent = this;
	this.instance_56.setTransform(252.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_57 = new lib.Символ15_1();
	this.instance_57.parent = this;
	this.instance_57.setTransform(243.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_58 = new lib.Символ15_1();
	this.instance_58.parent = this;
	this.instance_58.setTransform(235.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_59 = new lib.Символ15_1();
	this.instance_59.parent = this;
	this.instance_59.setTransform(226.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_60 = new lib.Символ15_1();
	this.instance_60.parent = this;
	this.instance_60.setTransform(218.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_61 = new lib.Символ15_1();
	this.instance_61.parent = this;
	this.instance_61.setTransform(212,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_62 = new lib.Символ15_1();
	this.instance_62.parent = this;
	this.instance_62.setTransform(204.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_63 = new lib.Символ15_1();
	this.instance_63.parent = this;
	this.instance_63.setTransform(194.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_64 = new lib.Символ15_1();
	this.instance_64.parent = this;
	this.instance_64.setTransform(187.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_65 = new lib.Символ15_1();
	this.instance_65.parent = this;
	this.instance_65.setTransform(181.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_66 = new lib.Символ15_1();
	this.instance_66.parent = this;
	this.instance_66.setTransform(173.9,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_67 = new lib.Символ15_1();
	this.instance_67.parent = this;
	this.instance_67.setTransform(164.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_68 = new lib.Символ15_1();
	this.instance_68.parent = this;
	this.instance_68.setTransform(156.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_69 = new lib.Символ15_1();
	this.instance_69.parent = this;
	this.instance_69.setTransform(150,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_70 = new lib.Символ15_1();
	this.instance_70.parent = this;
	this.instance_70.setTransform(142.4,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_71 = new lib.Символ15_1();
	this.instance_71.parent = this;
	this.instance_71.setTransform(132.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_72 = new lib.Символ15_1();
	this.instance_72.parent = this;
	this.instance_72.setTransform(125.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_73 = new lib.Символ15_1();
	this.instance_73.parent = this;
	this.instance_73.setTransform(119.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_74 = new lib.Символ15_1();
	this.instance_74.parent = this;
	this.instance_74.setTransform(112.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_75 = new lib.Символ15_1();
	this.instance_75.parent = this;
	this.instance_75.setTransform(102.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_76 = new lib.Символ15_1();
	this.instance_76.parent = this;
	this.instance_76.setTransform(95,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_77 = new lib.Символ15_1();
	this.instance_77.parent = this;
	this.instance_77.setTransform(88.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_78 = new lib.Символ15_1();
	this.instance_78.parent = this;
	this.instance_78.setTransform(80.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_79 = new lib.Символ15_1();
	this.instance_79.parent = this;
	this.instance_79.setTransform(71.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_80 = new lib.Символ15_1();
	this.instance_80.parent = this;
	this.instance_80.setTransform(63.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_81 = new lib.Символ15_1();
	this.instance_81.parent = this;
	this.instance_81.setTransform(57.8,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_82 = new lib.Символ15_1();
	this.instance_82.parent = this;
	this.instance_82.setTransform(50.2,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_83 = new lib.Символ15_1();
	this.instance_83.parent = this;
	this.instance_83.setTransform(40.6,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_84 = new lib.Символ15_1();
	this.instance_84.parent = this;
	this.instance_84.setTransform(33,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_85 = new lib.Символ15_1();
	this.instance_85.parent = this;
	this.instance_85.setTransform(26.3,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_86 = new lib.Символ15_1();
	this.instance_86.parent = this;
	this.instance_86.setTransform(18.7,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_87 = new lib.Символ15_1();
	this.instance_87.parent = this;
	this.instance_87.setTransform(9.1,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.instance_88 = new lib.Символ15_1();
	this.instance_88.parent = this;
	this.instance_88.setTransform(1.5,1.4,0.262,0.262,0,0,180,5.5,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ16_1, new cjs.Rectangle(0,0,681.3,2.9), null);


(lib.sprite152 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.instance = new lib.sprite150();
	this.instance.parent = this;
	this.instance.setTransform(0.2,-40.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.99,scaleY:1.01,y:-42.5},2).to({scaleX:0.93,scaleY:1.08,y:-49.4},2).to({scaleX:0.83,scaleY:1.18,y:-60.8},2).to({scaleX:0.89,scaleY:1.11,x:0.1,y:-65.4},1).to({scaleX:0.94,scaleY:1.07,y:-68.6},1).to({scaleX:0.97,scaleY:1.03,x:0.2,y:-70.7},1).to({scaleX:1,scaleY:1,y:-72.6},2).to({scaleX:1,scaleY:1,y:-72.8},1).to({scaleX:1,scaleY:1,y:-72.5},1).to({scaleX:0.99,scaleY:1.01,y:-71.5},1).to({scaleX:0.97,scaleY:1.03,y:-69.6},1).to({scaleX:0.94,scaleY:1.06,y:-66.5},1).to({scaleX:0.89,scaleY:1.1,y:-62.2},1).to({scaleX:0.79,scaleY:1.2,y:-51.9},2).to({scaleX:1,scaleY:1,y:-40.8},6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.2,-53.6,94.8,65.2);


(lib.sprite139 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.sprite138();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite139, new cjs.Rectangle(-106.5,-13.3,110.7,31.1), null);


(lib.sprite134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.sprite133();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-178.2},49).to({rotation:-181.8},1).to({rotation:-360},49).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-118.9,-115.5,230.8,231);


(lib.Символ45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ18_1();
	this.instance.parent = this;
	this.instance.setTransform(367.9,43,1,1,0,0,0,367.9,12.9);

	this.instance_1 = new lib.Символ17_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(316.9,13.4,1,1,0,0,0,316.9,5.5);

	this.instance_2 = new lib.Символ16_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(354.7,1.4,1,1,0,0,0,340.6,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ45, new cjs.Rectangle(0,0,736,55.9), null);


(lib.U = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.arrow = new lib.sprite152();
	this.arrow.parent = this;
	this.arrow.setTransform(6.4,23,0.228,0.342);
	this.arrow.shadow = new cjs.Shadow("#FF9900",0,0,11);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

}).prototype = getMCSymbolPrototype(lib.U, new cjs.Rectangle(-16.4,-7.3,49,50), null);


(lib.sprite140 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 7
	this.instance = new lib.sprite139();
	this.instance.parent = this;
	this.instance.setTransform(0,-143.5,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 3
	this.instance_1 = new lib.sprite139();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-148.7,-2.8,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer 1 - копия
	this.instance_2 = new lib.sprite139();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,147,1,1,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer 1
	this.instance_3 = new lib.sprite139();
	this.instance_3.parent = this;
	this.instance_3.setTransform(144.8,-2.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite140, new cjs.Rectangle(-152.8,-147.6,301.7,298.7), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 5
	this.instance = new lib.U();
	this.instance.parent = this;
	this.instance.setTransform(244.3,83.9,3.293,3.293,0,0,0,6.5,11.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40));

	// Слой 4
	this.instance_1 = new lib.Символ35();
	this.instance_1.parent = this;
	this.instance_1.setTransform(324.4,244,1,1,0,0,0,22.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(40));

	// Слой 2
	this.instance_2 = new lib.Символ20();
	this.instance_2.parent = this;
	this.instance_2.setTransform(107.5,124,1,1,0,0,0,62.5,124);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.83,x:117.8},9,cjs.Ease.get(-1)).to({regX:62.6,scaleX:0.64,x:129.1},10,cjs.Ease.get(1)).to({scaleX:0.82,x:118.4},10,cjs.Ease.get(-1)).to({regX:62.5,scaleX:1,x:107.5},10,cjs.Ease.get(1)).wait(1));

	// Слой 1
	this.instance_3 = new lib.Символ21();
	this.instance_3.parent = this;
	this.instance_3.setTransform(226,162,1,1,0,0,0,211,162);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15,0,422,324);


(lib.sprite141 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.sprite140();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,rotation:77.5},17).to({scaleX:1,scaleY:1,rotation:177.7,y:-0.1},22).to({rotation:182.3},1).to({scaleX:1,scaleY:1,rotation:259.7,x:0.1,y:0},17).to({scaleX:1,scaleY:1,rotation:360,x:0},22).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.8,-147.6,301.7,298.7);


(lib.Символ12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}
	this.frame_18 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(9).call(this.frame_18).wait(1));

	// Слой 14
	this.instance_1 = new lib.Символ28();
	this.instance_1.parent = this;
	this.instance_1.setTransform(366,324.7,1,1,0,0,0,149,24.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:344.3},4,cjs.Ease.get(-1)).to({y:368.7},5,cjs.Ease.get(1)).to({y:344.3},5,cjs.Ease.get(-1)).to({y:324.7},4,cjs.Ease.get(1)).wait(1));

	// Слой 13
	this.instance_2 = new lib.Символ24();
	this.instance_2.parent = this;
	this.instance_2.setTransform(305.6,21.2,1,1,0,0,0,267.6,24.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).to({y:71.2},5).to({y:21.2},4).wait(6));

	// Слой 16
	this.instance_3 = new lib.Символ45();
	this.instance_3.parent = this;
	this.instance_3.setTransform(380,-10,1.16,1.16,0,0,0,367.9,27.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({alpha:0.43},0).wait(9).to({alpha:1},0).wait(1));

	// Символ 9
	this.instance_4 = new lib.Символ9();
	this.instance_4.parent = this;
	this.instance_4.setTransform(201.5,120.5,1,1,0,0,0,104.5,59.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({y:140.5,alpha:0},9).to({y:120.5,alpha:1},9).wait(1));

	// Символ 3
	this.instance_5 = new lib.Символ3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(446.5,-143,1,1,0,0,0,218.5,162);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:162.1,scaleY:0.94,y:197.6},7).to({regY:162,scaleY:1,y:187},2).to({x:1024.5},9).wait(1));

	// Символ 8
	this.instance_6 = new lib.Символ14_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(103.5,308.5,1,1,0,0,0,103.5,233.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:-105.5},9).to({x:113.5},7).to({x:103.5},2).wait(1));

	// Слой 15
	this.instance_7 = new lib.Символ31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(617.5,195.6,0.46,0.94,0,-90,90,336.1,50.5);

	this.instance_8 = new lib.Символ31();
	this.instance_8.parent = this;
	this.instance_8.setTransform(72.6,195.5,0.46,0.94,0,90,-90,336.1,50.5);

	this.instance_9 = new lib.Символ31();
	this.instance_9.parent = this;
	this.instance_9.setTransform(348.1,88.4,1,0.94,0,180,0,336.1,50.5);

	this.instance_10 = new lib.Символ31();
	this.instance_10.parent = this;
	this.instance_10.setTransform(348.1,305.5,1,1,0,0,0,336.1,50.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7}]}).wait(19));

	// Символ 5
	this.instance_11 = new lib.Символ5();
	this.instance_11.parent = this;
	this.instance_11.setTransform(464,203.5,1,1,0,0,0,186,149.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({regY:149.6,scaleX:0.51,scaleY:0.51,x:769.5,y:277.7},9).to({scaleX:1.05,scaleY:1.05,x:454.3,y:196.6},6).to({regY:149.5,scaleX:1,scaleY:1,x:464,y:203.5},3).wait(1));

	// money
	this.instance_12 = new lib.Символ38();
	this.instance_12.parent = this;
	this.instance_12.setTransform(344.5,301,1,1,0,0,0,352.5,76);
	this.instance_12.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({alpha:1},9).to({alpha:0},9).wait(1));

	// money - копия
	this.instance_13 = new lib.Символ37();
	this.instance_13.parent = this;
	this.instance_13.setTransform(344.5,301,1,1,0,0,0,352.5,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(19));

	// Символ 7
	this.instance_14 = new lib.Символ7();
	this.instance_14.parent = this;
	this.instance_14.setTransform(651,180,1,1,0,0,0,129,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({scaleX:0.93,scaleY:0.93,x:695.3,y:193.4},4,cjs.Ease.get(-1)).to({regX:129.1,regY:180.1,scaleX:0.83,scaleY:0.83,x:750.6,y:210.2},5,cjs.Ease.get(1)).to({scaleX:0.93,scaleY:0.93,x:695.3,y:193.5},5,cjs.Ease.get(-1)).to({regX:129,regY:180,scaleX:1,scaleY:1,x:651,y:180},4,cjs.Ease.get(1)).wait(1));

	// Слой 31
	this.instance_15 = new lib.Символ15();
	this.instance_15.parent = this;
	this.instance_15.setTransform(240,242.7,1,1,0,0,0,92,89.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({scaleX:1.13,scaleY:1.13,x:198.2,y:235.4},4,cjs.Ease.get(-1)).to({scaleX:1.28,scaleY:1.28,x:146,y:226.4},5,cjs.Ease.get(1)).to({scaleX:1.16,scaleY:1.16,x:187.8,y:233.6},4,cjs.Ease.get(-1)).to({scaleX:1,scaleY:1,x:240,y:242.7},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47,-305,854.1,847);


(lib.sprite144 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF00").ss(22.5,1,1).p("AWJAAQAAJMmfGeQmeGfpMAAQpLAAmemfQmfmeAApMQAApLGfmeQGemfJLAAQJMAAGeGfQGfGeAAJLg");
	this.shape.setTransform(-2.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(27));

	// Layer 8
	this.instance = new lib.sprite143();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.251,0.251);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.47,scaleY:0.47},3).to({scaleX:0.65,scaleY:0.65},3).to({scaleX:0.79,scaleY:0.79},3).to({scaleX:0.9,scaleY:0.9},3).to({scaleX:0.97,scaleY:0.97},3).to({scaleX:0.38,scaleY:0.38},4).to({scaleX:0.25,scaleY:0.25},7).wait(1));

	// Layer 6
	this.instance_1 = new lib.sprite141();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0.2,2.099,2.099);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.88,scaleY:1.88,y:0.1},2).to({scaleX:1.69,scaleY:1.69},2).to({scaleX:1.52,scaleY:1.52},2).to({scaleX:1.37,scaleY:1.37},2).to({scaleX:1.25,scaleY:1.25},2).to({scaleX:1.15,scaleY:1.15},2).to({scaleX:1.08,scaleY:1.08},2).to({scaleX:1.03,scaleY:1.03,y:0},2).to({scaleX:1.01,scaleY:1.01},1).to({scaleX:1,scaleY:1},2).to({scaleX:2.1,scaleY:2.1,y:0.2},7).wait(1));

	// Layer 3
	this.instance_2 = new lib.sprite136();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0,5.843,5.843);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:5.41,scaleY:5.41},1).to({scaleX:4.99,scaleY:4.99},1).to({scaleX:4.6,scaleY:4.6},1).to({scaleX:4.23,scaleY:4.23},1).to({scaleX:3.89,scaleY:3.89},1).to({scaleX:3.57,scaleY:3.57},1).to({scaleX:3.28,scaleY:3.28},1).to({scaleX:3,scaleY:3},1).to({scaleX:2.75,scaleY:2.75},1).to({scaleX:2.53,scaleY:2.53},1).to({scaleX:2.33,scaleY:2.33},1).to({scaleX:2.15,scaleY:2.15},1).to({scaleX:2,scaleY:2},1).to({scaleX:1.87,scaleY:1.87},1).to({scaleX:1.76,scaleY:1.76},1).to({scaleX:1.68,scaleY:1.68},1).to({scaleX:1.62,scaleY:1.62},1).to({scaleX:1.57,scaleY:1.57},2).to({scaleX:5.84,scaleY:5.84},7).wait(1));

	// Layer 1
	this.instance_3 = new lib.sprite134();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1,0.2,1.594,1.594);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1.53,scaleY:1.53},1).to({scaleX:1.37,scaleY:1.37},3).to({scaleX:1.2,scaleY:1.2},4).to({scaleX:1.08,scaleY:1.08},4).to({scaleX:1.03,scaleY:1.03},3).to({scaleX:1.01,scaleY:1.01},1).to({scaleX:1.01,scaleY:1.01},1).to({scaleX:1,scaleY:1},2).to({scaleX:1.59,scaleY:1.59},7).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-320.8,-309.7,633.4,627.1);


(lib.Символ36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.instance = new lib.sprite144();
	this.instance.parent = this;
	this.instance.setTransform(-74.5,78.8,0.084,0.084);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18));

	// Слой 1
	this.instance_1 = new lib.lopata_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(112.1,41.6,1,1,55,0,0,35.1,-38);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:35,rotation:-9.4,y:41.5},14).to({regX:35.1,rotation:55,y:41.6},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.4,-74,271.5,217.3);


(lib.Символ40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Слой 1
	this.instance = new lib.Символ36();
	this.instance.parent = this;
	this.instance.setTransform(-31.1,95.5,0.978,1,0,0,180,77,79.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


// stage content:
(lib.gelic_640x305 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.canvas.style.cursor = "none";
		this.pricel.mouseEnabled = false;
		this.addEventListener("tick", fl_CustomMouseCursor9.bind(this));
		
		function fl_CustomMouseCursor9() {
			this.pricel.x = stage.mouseX/window.devicePixelRatio;
			this.pricel.y = stage.mouseY/window.devicePixelRatio;
		}
		
		
		stage.canvas.addEventListener("mouseover", fl_mouseover.bind(this));
		function fl_mouseover()
		{
		this.vse.gotoAndPlay(1);
		this.pricel.gotoAndStop(1);
		}
		
		stage.canvas.addEventListener("mouseout", fl_mouseout.bind(this));
		
		function fl_mouseout()
		{
		this.vse.gotoAndPlay(11);
			this.pricel.gotoAndStop(0);
		}
		
		this.addEventListener("tick", fl_CustomMouseCursor.bind(this));
		
		function fl_CustomMouseCursor() {
		
		this.fon.x = - stage.mouseX / 10 /window.devicePixelRatio;
		this.fon.y = - stage.mouseY / 10 /window.devicePixelRatio;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// lopata
	this.pricel = new lib.Символ40();
	this.pricel.parent = this;
	this.pricel.setTransform(36.7,212.7,1,1,0,0,0,132.7,108.7);

	this.timeline.addTween(cjs.Tween.get(this.pricel).wait(1));

	// ne_komplex
	this.vse = new lib.Символ12_1();
	this.vse.parent = this;
	this.vse.setTransform(597.5,227,1,1,0,0,0,621.5,270.9);

	this.timeline.addTween(cjs.Tween.get(this.vse).wait(1));

	// Слой 1
	this.fon = new lib.Символ2();
	this.fon.parent = this;
	this.fon.setTransform(-31,28.5,1,1,0,0,0,399,210.5);

	this.timeline.addTween(cjs.Tween.get(this.fon).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(233.1,-196.5,870,847);
// library properties:
lib.properties = {
	width: 640,
	height: 305,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/buble.png?1481295010397", id:"buble"},
		{src:"images/dver.png?1481295010397", id:"dver"},
		{src:"images/fon.jpg?1481295010397", id:"fon"},
		{src:"images/gelickkk.png?1481295010397", id:"gelickkk"},
		{src:"images/gilick.png?1481295010397", id:"gilick"},
		{src:"images/girl.png?1481295010397", id:"girl"},
		{src:"images/kesh_presuy.png?1481295010397", id:"kesh_presuy"},
		{src:"images/lopata.png?1481295010397", id:"lopata"},
		{src:"images/money.png?1481295010397", id:"money"},
		{src:"images/ne_komplex.png?1481295010397", id:"ne_komplex"},
		{src:"images/rou.png?1481295010397", id:"rou"},
		{src:"images/tree.png?1481295010397", id:"tree"},
		{src:"images/zad.png?1481295010397", id:"zad"},
		{src:"images/Слой31.png?1481295010397", id:"Слой31"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;